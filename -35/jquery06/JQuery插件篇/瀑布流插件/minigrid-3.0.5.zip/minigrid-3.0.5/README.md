# Minigrid

Minigrid is a minimal 2kb zero dependency cascading grid layout.

Website & Documentation: [http://alves.im/minigrid](http://minigrid.js.org/).

## Contributing

Plese see [CONTRIBUTING](CONTRIBUTING.md).

## License

MIT &copy; 2016 [Henrique Alves](http://alves.im)
